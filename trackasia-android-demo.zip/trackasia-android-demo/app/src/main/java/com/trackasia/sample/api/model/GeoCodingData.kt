package com.trackasia.sample.api.model

data class GeoCodingData(
    val name: String?,
    val long: String?,
    val lat: String?
)