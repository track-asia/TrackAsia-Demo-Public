//
//  MenuPointView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//
import SwiftUI
import Mapbox
import Alamofire
import Combine
import GoogleMaps
import MapKit

struct MapCompareGoogleView: View {
    @State private var searchText: String = ""
    private var timer: Timer?
    @FocusState private var isTextFieldFocused: Bool
    @EnvironmentObject private var countrySettings: CountrySettings
    @State private var googleMapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 21.028511, longitude: 105.8544),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    @State private var mapboxCoordinate = CLLocationCoordinate2D(latitude: 21.028511, longitude: 105.8544)
    @ObservedObject private var viewModel: MapCompareViewModel = MapCompareViewModel()
    
    var body: some View {
        VStack {
            GoogleMapView(region: $googleMapRegion)
                .frame(height: 300)
            
            MapCompareController(viewModel: viewModel)
                .frame(height: 300)
        }
        .navigationTitle("Map Comparison").onChange(of: countrySettings.selectedCountry) { selectedCountry in
//            print("MapCompareGoogleView Selected Country in MapSinglePointView changed to: \(selectedCountry)")
//            viewModel.updateMap(selectedCountry: selectedCountry)
            
        }.environmentObject(countrySettings)
    }
}
