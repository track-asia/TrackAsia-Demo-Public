//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit

class MapAnimationViewModel: ObservableObject {
    @Published var onLocationSelected: ((CLLocationCoordinate2D, String?) -> Void)?
    @Published var geoCodingModel = GeocodingRepository()
    @Published var routes: [Route]? = []
    @Published var waypoints: [Waypoint]? = []
    @StateObject var locationManager = LocationManager()
    @Published var mapViewManager = MapViewManager()
    var onLocationSelectedCallback: ((CLLocationCoordinate2D, String?) -> Void)?
    
    func addMarker(at coordinate: CLLocationCoordinate2D, title: String?) {
         mapViewManager.addMarker(at: coordinate, title: title)
     }

     func moveCamera(to coordinate: CLLocationCoordinate2D, zoom: Double) {
         mapViewManager.moveCamera(to: coordinate, zoom: zoom)
     }

     func centerOnUserLocation() {
         mapViewManager.centerOnUserLocation()
     }

     func updateMap(selectedCountry: String) {
         mapViewManager.updateMap(selectedCountry: selectedCountry)
     }
    
    func removeRoute(){
        mapViewManager.mapView.removeRoutes()
        mapViewManager.mapView.removeWaypoints()
    }
    
}

struct MapAnimationController: UIViewRepresentable {
    @ObservedObject var viewModel: MapAnimationViewModel
    
    init(viewModel: MapAnimationViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        let mapView = viewModel.mapViewManager.mapView
        mapView.delegate = context.coordinator
        return mapView
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapAnimationController
        var markerManager: MarkerManager?
        var routeHandler: RouteHandler = RouteHandler()
        var animationLineView: AnimationLineView?
        
        
        init(parent: MapAnimationController) {
            self.parent = parent
            super.init()
            self.parent.viewModel.mapViewManager.mapView.delegate = self
            animationLineView = AnimationLineView()
        }
        
        func mapView(_ mapView: MGLMapView, didFinishLoading style: MGLStyle) {
            animationLineView?.style = parent.viewModel.mapViewManager.mapView.style
            animationLineView?.addPolyline(to: parent.viewModel.mapViewManager.mapView.style!, mapview: mapView)
            animationLineView?.animatePolyline()
        }
        
        
        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            let point = gesture.location(in: parent.viewModel.mapViewManager.mapView)
            let coordinate = parent.viewModel.mapViewManager.mapView.convert(point, toCoordinateFrom: parent.viewModel.mapViewManager.mapView)
            getInfoGeocoding(coordinate: coordinate, gesture)
            self.parent.viewModel.waypoints?.append(Waypoint(coordinate: coordinate, name: "Waypoint"))
            self.routeHandler.waypoints = self.parent.viewModel.waypoints!
            if(self.parent.viewModel.waypoints?.count ?? 0 > 1){
                self.routeHandler.handleRequestRoute(success: self.routeHandler.defaultSuccess, failure: self.routeHandler.defaultFailure)
                self.routeHandler.routesUpdatedCallback = { routes, waypoints in
                    self.parent.viewModel.routes = routes
                    self.parent.viewModel.waypoints = waypoints!
//                    self.parent.viewModel.mapViewManager.mapView.showRoutes(routes!)
                }
            }
        }
        
        
        func getInfoGeocoding(coordinate: CLLocationCoordinate2D,_ gesture: UITapGestureRecognizer){
            var title = ""
            parent.viewModel.geoCodingModel.fetchGeocoding(lat: String(format: "%.12f", coordinate.latitude), lng: String(format: "%.12f", coordinate.longitude))
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if(self.parent.viewModel.geoCodingModel.addresses.isEmpty == false){
                    title = self.parent.viewModel.geoCodingModel.addresses[0].label
                    if(self.parent.viewModel.onLocationSelected != nil){
                        self.parent.viewModel.onLocationSelected!(coordinate,title)
                    }
                }
            }
        }
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
        viewModel.mapViewManager.mapView.delegate = context.coordinator
    }
    
    func centerOnUserLocation() {
        if let userLocation = viewModel.locationManager.userLocation {
            viewModel.mapViewManager.mapView.setCenter(userLocation.coordinate, zoomLevel: 8, animated: true)
        }
    }
    
    func moveCamera(to coordinate: CLLocationCoordinate2D) {
        viewModel.mapViewManager.mapView.setCenter(coordinate, zoomLevel: viewModel.mapViewManager.zoomLevelCurrent, animated: true)
    }
}
