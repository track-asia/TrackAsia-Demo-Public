//
//  RouteHandler.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 26/12/2023.
//

import Mapbox
import MapboxCoreNavigation
import MapboxDirections

typealias RouteRequestSuccess = (([Route]) -> Void)
typealias RouteRequestFailure = ((Error) -> Void)

class RouteHandler: ObservableObject {
//    private var mapView: MGLMapView
    @Published var routes: [Route]?
    @Published var waypoints: [Waypoint] = []
    
    var routesUpdatedCallback: (([Route]?, [Waypoint]?) -> Void)?

    func handleRequestRoute(success: @escaping RouteRequestSuccess, failure: RouteRequestFailure?) {
        guard waypoints.count > 0 else { return }
        let options = NavigationRouteOptions(waypoints: waypoints, profileIdentifier: MBDirectionsProfileIdentifier.car)
        requestRoute(with: options, success: success, failure: failure)
    }

    private func requestRoute(with options: RouteOptions, success: @escaping RouteRequestSuccess, failure: RouteRequestFailure?) {
        let handler: Directions.RouteCompletionHandler = { waypoints, potentialRoutes, potentialError in
            if let error = potentialError {
                print("Error calculating route: \(error)")
                failure?(error)
            }
//            print("waypoints calculated successfully: \(waypoints)")
            if let routes = potentialRoutes {
//                print("Route calculated successfully: \(routes)")
                
//                if let jsonData = try? JSONSerialization.data(withJSONObject: routes, options: []),
//                    let decodedRoute = try? JSONDecoder().decode(Routelog.self, from: jsonData),
//                    let firstStep = decodedRoute.legs.first?.steps.first {
//                    let coordinates = firstStep.maneuver.location
//                    let formattedCoordinates = "[\(coordinates[0]), \(coordinates[1])]"
//                    print(formattedCoordinates)
//                } else {
//                    print("Không có thông tin tọa độ.")
//                }
                success(routes)
            }
            
        }

        Directions.shared.calculate(options, completionHandler: handler)
    }

    lazy var defaultSuccess: RouteRequestSuccess = { [weak self] routes in
        guard let current = routes.first else { return }
        self?.routes = routes
        self?.waypoints = current.routeOptions.waypoints
        self?.routesUpdatedCallback?(self?.routes, self?.waypoints)
    }

    lazy var defaultFailure: RouteRequestFailure = { error in
        print(error.localizedDescription)
    }
    
    struct Routelog: Decodable {
        let legs: [Leg]
    }

    struct Leg: Decodable {
        let steps: [Step]
    }

    struct Step: Decodable {
        let maneuver: Maneuver
    }

    struct Maneuver: Decodable {
        let location: [Double]
    }
}

