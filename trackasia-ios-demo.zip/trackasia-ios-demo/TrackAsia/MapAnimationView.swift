//
//  MenuPointView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//
import SwiftUI
import Mapbox
struct MapAnimationView: View {
    @EnvironmentObject private var countrySettings: CountrySettings
    @ObservedObject private var viewModel: MapAnimationViewModel = MapAnimationViewModel()
    
    var body: some View {
        NavigationView {
            ZStack{
                MapAnimationController(viewModel: viewModel)
            }.onChange(of: countrySettings.selectedCountry) { selectedCountry in
//                print("MapAnimationView Selected Country in MapSinglePointView changed to: \(selectedCountry)")
//                viewModel.updateMap(selectedCountry: selectedCountry)
                
            }
        }.environmentObject(countrySettings)
    }
}
