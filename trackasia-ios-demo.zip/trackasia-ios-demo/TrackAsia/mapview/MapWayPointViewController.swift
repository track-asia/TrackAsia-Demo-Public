//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit

class MapWaypointViewModel: ObservableObject {
    @Published var onLocationSelected: ((CLLocationCoordinate2D, String?) -> Void)?
    @Published var geoCodingModel = GeocodingRepository()
    @Published var petLocationModel = PetLocationRepository()
    @Published var markerManager: MarkerManager?
    @Published var routes: [Route]? = []
    @Published var waypoints: [Waypoint]? = []
    @Published var waypointIndex = 1
    @StateObject var locationManager = LocationManager()
    @Published var mapViewManager = MapViewManager()
    
    init(onLocationSelected: @escaping ((CLLocationCoordinate2D, String?) -> Void)) {
        self.onLocationSelected = onLocationSelected
    }
    

    func addMarker(at coordinate: CLLocationCoordinate2D, title: String?) {
         mapViewManager.addMarker(at: coordinate, title: title)
     }

     func moveCamera(to coordinate: CLLocationCoordinate2D, zoom: Double) {
         mapViewManager.moveCamera(to: coordinate, zoom: zoom)
     }

     func centerOnUserLocation() {
         mapViewManager.centerOnUserLocation()
     }

     func updateMap(selectedCountry: String) {
         mapViewManager.updateMap(selectedCountry: selectedCountry)
     }
    
    func removeRoute(){
        mapViewManager.mapView.removeRoutes()
        mapViewManager.mapView.removeWaypoints()
        waypointIndex = 1
    }

    
}

struct MapWaypointViewController: UIViewRepresentable {
    @ObservedObject var viewModel: MapWaypointViewModel
    
    init(viewModel: MapWaypointViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        let mapView = viewModel.mapViewManager.mapView
        mapView.delegate = context.coordinator

        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.handleTap(_:)))
        mapView.addGestureRecognizer(tapGesture)
        
        return mapView
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapWaypointViewController
        var markerManager: MarkerManager?
        var routeHandler: RouteHandler = RouteHandler()
        var animationLineView: AnimationLineView?
        
        
        init(parent: MapWaypointViewController) {
            self.parent = parent
            super.init()
            self.parent.viewModel.mapViewManager.mapView.delegate = self
        }
        
        func mapView(_ mapView: MGLMapView, didFinishLoading style: MGLStyle) {
            
        }
        
        func mapView(_ mapView: MGLMapView, viewFor annotation: MGLAnnotation) -> MGLAnnotationView? {
            return WaypointView.view(for: annotation)
        }
        
        
        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            let point = gesture.location(in: parent.viewModel.mapViewManager.mapView)
            let coordinate = parent.viewModel.mapViewManager.mapView.convert(point, toCoordinateFrom: parent.viewModel.mapViewManager.mapView)
            getInfoGeocoding(coordinate: coordinate, gesture)
            self.parent.viewModel.waypoints?.append(Waypoint(coordinate: coordinate, name: "Waypoint"))
            self.routeHandler.waypoints = self.parent.viewModel.waypoints!
            if(self.parent.viewModel.waypoints?.count ?? 0 > 1){
                self.routeHandler.handleRequestRoute(success: self.routeHandler.defaultSuccess, failure: self.routeHandler.defaultFailure)
                self.routeHandler.routesUpdatedCallback = { routes, waypoints in
                    self.parent.viewModel.routes = routes
                    self.parent.viewModel.waypoints = waypoints!
                    self.parent.viewModel.mapViewManager.mapView.showRoutes(routes!)
                }
            }
        }
        
        
        func getInfoGeocoding(coordinate: CLLocationCoordinate2D,_ gesture: UITapGestureRecognizer){
            var title = ""
            parent.viewModel.geoCodingModel.fetchGeocoding(lat: String(format: "%.12f", coordinate.latitude), lng: String(format: "%.12f", coordinate.longitude))
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if(self.parent.viewModel.geoCodingModel.addresses.isEmpty == false){
                    title = self.parent.viewModel.geoCodingModel.addresses[0].label
                    self.parent.viewModel.onLocationSelected?(coordinate,title )
                    self.parent.viewModel.addMarker(at: coordinate, title: String(self.parent.viewModel.waypointIndex))
                    self.parent.viewModel.waypointIndex += 1
                }
            }
        }
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
    }
    
    func centerOnUserLocation() {
        if let userLocation = viewModel.locationManager.userLocation {
            viewModel.mapViewManager.mapView.setCenter(userLocation.coordinate, zoomLevel: 8, animated: true)
        }
    }
    
    func removeRoute(){
        viewModel.removeRoute()
    }
}

