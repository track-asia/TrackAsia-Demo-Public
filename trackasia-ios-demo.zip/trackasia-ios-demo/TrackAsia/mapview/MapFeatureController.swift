//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit

class MapFeatureViewModel: ObservableObject {
    @Published var petLocationModel = PetLocationRepository()
    @EnvironmentObject var markerManager: MarkerManager
    @StateObject var locationManager = LocationManager()
    @Published var mapViewManager = MapViewManager()
    
    func addMarker() {
        let locations = [
            CLLocationCoordinate2D(latitude: 21.028511, longitude: 105.854444), // Hanoi
            CLLocationCoordinate2D(latitude: 10.823099, longitude: 106.629662), // Ho Chi Minh City
            CLLocationCoordinate2D(latitude: 16.463714, longitude: 107.590866)  // Hue
        ]
        for location in locations {
            markerManager.addMarker(at: location, title: "", zoomlevel: 5)
        }
    }
    
    func centerOnUserLocation() {
        mapViewManager.centerOnUserLocation()
    }
    
    func updateMap(selectedCountry: String) {
        mapViewManager.updateMap(selectedCountry: selectedCountry)
    }
    
}

struct MapFeatureViewController: UIViewRepresentable {
    @ObservedObject var viewModel: MapFeatureViewModel
    
    init(viewModel: MapFeatureViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        let mapView = viewModel.mapViewManager.mapView
        mapView.delegate = context.coordinator
        
        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.handleTap(_:)))
        mapView.addGestureRecognizer(tapGesture)
        
        return mapView
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapFeatureViewController
        var markerManager: MarkerManager?
        var routeHandler: RouteHandler = RouteHandler()
        var animationLineView: AnimationLineView?
        
        
        init(parent: MapFeatureViewController) {
            self.parent = parent
            super.init()
            self.parent.viewModel.mapViewManager.mapView.delegate = self
        }
        
        func mapView(_ mapView: MGLMapView, didFinishLoading style: MGLStyle) {
            
        }
        
        func mapView(_ mapView: MGLMapView, viewFor annotation: MGLAnnotation) -> MGLAnnotationView? {
            return WaypointView.view(for: annotation)
        }
        
        
        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            let point = gesture.location(in: parent.viewModel.mapViewManager.mapView)
            _ = parent.viewModel.mapViewManager.mapView.convert(point, toCoordinateFrom: parent.viewModel.mapViewManager.mapView)
        }
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
    }
    
    func centerOnUserLocation() {
        if let userLocation = viewModel.locationManager.userLocation {
            viewModel.mapViewManager.mapView.setCenter(userLocation.coordinate, zoomLevel: 8, animated: true)
        }
    }
    
}



