//
//  WayPointView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 26/12/2023.
//

import Mapbox
import MapboxCoreNavigation
import MapKit

struct WaypointView {
    
    weak var mapView: MGLMapView?

    init(mapView: MGLMapView) {
        self.mapView = mapView
    }

    static func view(for annotation: MGLAnnotation) -> MGLAnnotationView? {
        guard let pointAnnotation = annotation as? MGLPointAnnotation else {
            return nil
        }

        let annotationView = MGLAnnotationView(reuseIdentifier: "pointAnnotation")
        let iconSize = CGSize(width: 60, height: 60)

        if let title = pointAnnotation.title {
            let label = UILabel(frame: CGRect(x: 8, y: -16, width: 16, height: 16))
            label.text = title
            label.textColor = UIColor.white
            label.textAlignment = .center
            label.backgroundColor = UIColor.blue
            label.layer.cornerRadius = label.frame.width / 2
            label.layer.masksToBounds = true

            let customView = UIView(frame: CGRect(x: -16, y: -24, width: iconSize.width, height: iconSize.height))
            customView.addSubview(label)
            customView.addSubview(UIImageView(image: UIImage(named: "ic_location")))
            annotationView.addSubview(customView)

            return annotationView
        }

        return nil
    }
    
    static func addWaypoints(mapView: MGLMapView, waypoints: [Waypoint]) {
        for (index, waypoint) in waypoints.enumerated() {
            let marker = MGLPointAnnotation()
            marker.coordinate = waypoint.coordinate
            marker.title = String(index + 1)
            mapView.addAnnotation(marker)
        }
    }
    
    static func onWaypoints(mapView: MGLMapView, waypoints: [Waypoint]) {
        if waypoints.count >= 2 {
            let origin = waypoints[0]
            let destination = waypoints.last!
            
            let originMarker = MGLPointAnnotation()
            originMarker.coordinate = origin.coordinate
            originMarker.title = "Origin"
            mapView.addAnnotation(originMarker)
            
            let destinationMarker = MGLPointAnnotation()
            destinationMarker.coordinate = destination.coordinate
            destinationMarker.title = "Destination"
            mapView.addAnnotation(destinationMarker)
        }
    }
}
