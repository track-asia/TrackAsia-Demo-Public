//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit


class MapClusterViewModel: ObservableObject {
    @Published var petLocationModel = PetLocationRepository()
    @EnvironmentObject var markerManager: MarkerManager
    var clusterView: ClusterView?
    @StateObject var locationManager = LocationManager()
    @Published var mapViewManager = MapViewManager()
    
    init() {
        clusterView?.setupCluster()
        if let userLocation = locationManager.userLocation {
            mapViewManager.mapView.setCenter(userLocation.coordinate, animated: true)
        }
    }
    
    func updateMap(selectedCountry: String) {
        mapViewManager.updateMap(selectedCountry: selectedCountry)
    }
    
}

struct MapClusterController: UIViewRepresentable {
    @ObservedObject var viewModel: MapClusterViewModel
    
    init(viewModel: MapClusterViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        let mapView = viewModel.mapViewManager.mapView
        return mapView
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapClusterController
        var clusterView: ClusterView?
        
        
        init(parent: MapClusterController) {
            self.parent = parent
            super.init()
            self.parent.viewModel.mapViewManager.mapView.delegate = self
            clusterView = ClusterView(mapView: parent.viewModel.mapViewManager.mapView)
        }
        
        func mapView(_ mapView: MGLMapView, didFinishLoading style: MGLStyle) {
            clusterView?.setupCluster()
        }
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
        viewModel.mapViewManager.mapView.delegate = context.coordinator
    }
    
}
