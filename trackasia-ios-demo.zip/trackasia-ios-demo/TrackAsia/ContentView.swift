//
//  ContentView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import SwiftUI
import MapKit

struct ContentView: View {
//    @State private var selectedCountry = "vn"
    @StateObject private var countrySettings = CountrySettings()
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 10.728073, longitude: 106.624054),
        span: MKCoordinateSpan(latitudeDelta: 10.0, longitudeDelta: 10.0)
    )
    @State private var showDropdown = false
    @State private var currentPage = 0
    @State private var countries: [String: String] = [
        "vn": "Vietnam",
        "sg": "Singapore",
        "th": "Thailand",
        "tw": "Taiwan",
        "my": "Malaysia"
    ]
    let tabTitles = ["Single Point", "Way Point", "Clutter", "Animation", "Feature"]
    var body: some View {
        VStack {
            // Menu bar
            HStack {
                Text(tabTitles[currentPage])
                    .font(.headline)
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer()
                Button(action: {
                    showDropdown.toggle()
                }) {
                    Label(MapUtils.getNameContry(idCountry: countrySettings.selectedCountry), systemImage: "globe")
                }
                .popover(isPresented: $showDropdown) {
                    List(countries.keys.sorted(), id: \.self) { key in
                        Button(action: {
                            countrySettings.selectedCountry = key
                            UserDefaults.standard.set(key, forKey: "selectedCountry")
                            showDropdown.toggle()
                        }) {
                            Text(countries[key] ?? "Unknown")
                        }
                    }
                }
                Spacer()
            }
            .padding()
            TabView(selection: $currentPage) {
                ForEach(0..<tabTitles.count, id: \.self) { index in
                    getTabView(index)
                        .tabItem {
                            Image(systemName: getTabImageName(index))
                            Text(tabTitles[index])
                        }
                        .tag(index)
                }
            }
            .onAppear {
                if let storedCountry = UserDefaults.standard.string(forKey: "selectedCountry") {
                    countrySettings.selectedCountry = storedCountry
                }
            }
        }.environmentObject(countrySettings)
    }
    
    @ViewBuilder
    func getTabView(_ index: Int) -> some View {
        switch index {
        case 0:
            MapSinglePointView()
        case 1:
            MapWayPointView()
        case 2:
            MapClutterView()
        case 3:
            MapAnimationView()
        case 4:
            MapFeatureView()
        default:
            EmptyView()
        }
    }
    
    func getTabImageName(_ index: Int) -> String {
        switch index {
        case 0:
            return "location.fill"
        case 1:
            return "map.fill"
        case 2:
            return "square.fill"
        case 3:
            return "arrow.triangle.turn.up.right.circle.fill"
        case 4:
            return "star.fill"
        default:
            return ""
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

#Preview {
    ContentView()
}

