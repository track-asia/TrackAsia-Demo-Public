//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit

class MapViewModel: ObservableObject {
    @Published var mapViewManager = MapViewManager()
    
    func addMarker(at coordinate: CLLocationCoordinate2D, title: String?) {
         mapViewManager.addMarker(at: coordinate, title: title)
     }

     func moveCamera(to coordinate: CLLocationCoordinate2D, zoom: Double) {
         mapViewManager.moveCamera(to: coordinate, zoom: zoom)
     }

     func centerOnUserLocation() {
         mapViewManager.centerOnUserLocation()
     }

     func updateMap(selectedCountry: String) {
         mapViewManager.updateMap(selectedCountry: selectedCountry)
     }
}

struct MapViewController: UIViewRepresentable {
    @ObservedObject var viewModel: MapViewModel
    
    init(viewModel: MapViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        viewModel.mapViewManager.mapView.delegate = context.coordinator
        return viewModel.mapViewManager.mapView
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
        uiView.delegate = context.coordinator
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapViewController
        
        init(parent: MapViewController) {
            self.parent = parent
            super.init()
        }
    }
}
