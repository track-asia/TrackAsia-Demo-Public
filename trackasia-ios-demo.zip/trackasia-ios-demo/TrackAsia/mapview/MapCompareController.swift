//
//  MapViewController.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//

import Foundation
import SwiftUI
import Mapbox
import CoreLocation
import MapboxCoreNavigation
import MapboxNavigation
import MapboxDirections
import MapKit
import GoogleMaps



struct GoogleMapView: UIViewRepresentable {
    @Binding var region: MKCoordinateRegion
    func makeUIView(context: Context) -> GMSMapView {
        let camera = GMSCameraPosition.camera(withLatitude: 21.028511, longitude: 105.8544, zoom: 12.0)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        mapView.settings.scrollGestures = true
        mapView.camera = camera
        return mapView
    }

    func updateUIView(_ uiView: GMSMapView, context: Context) {
        uiView.animate(to: GMSCameraPosition(
                  target: CLLocationCoordinate2D(latitude: region.center.latitude, longitude: region.center.longitude),
                  zoom: Float(region.span.latitudeDelta)
              ))
    }
}




class MapCompareViewModel: ObservableObject {
    @Published var selectedLocation: (CLLocationCoordinate2D, String?)?
    var onLocationSelectedCallback: ((CLLocationCoordinate2D, String?) -> Void)?
    @Published var mapViewManager = MapViewManager()
    
    func invokeOnLocationSelected(coordinate: CLLocationCoordinate2D, name: String?) {
        onLocationSelectedCallback?(coordinate, name)
    }
    
    func moveCamera(to coordinate: CLLocationCoordinate2D, zoom: Double) {
        mapViewManager.moveCamera(to: coordinate, zoom: zoom)
    }

    func centerOnUserLocation() {
        mapViewManager.centerOnUserLocation()
    }
    
    func updateMap(selectedCountry: String) {
        mapViewManager.updateMap(selectedCountry: selectedCountry)
    }
}

struct MapCompareController: UIViewRepresentable {
    @ObservedObject var viewModel: MapCompareViewModel
    
    init(viewModel: MapCompareViewModel) {
        self.viewModel = viewModel
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> MGLMapView {
        viewModel.mapViewManager.mapView.delegate = context.coordinator
        return viewModel.mapViewManager.mapView
    }
    
    func updateUIView(_ uiView: MGLMapView, context: Context) {
        uiView.delegate = context.coordinator
    }
    
    class Coordinator: NSObject, MGLMapViewDelegate {
        var parent: MapCompareController
        
        init(parent: MapCompareController) {
            self.parent = parent
            super.init()
        }
    }
}

class MapboxDelegate: NSObject, MGLMapViewDelegate {
    var onRegionDidChange: ((CLLocationCoordinate2D) -> Void)?

    func mapView(_ mapView: MGLMapView, regionDidChangeAnimated animated: Bool) {
        let center = mapView.centerCoordinate
        onRegionDidChange?(center)
    }
}



