//
//  MenuPointView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//
import SwiftUI
import Mapbox
struct MapWayPointView: View {
    @EnvironmentObject private var countrySettings: CountrySettings
    @ObservedObject private var viewModel: MapWaypointViewModel = MapWaypointViewModel(onLocationSelected: { location, name in })
    @State private var mapUpdateToken = UUID()
    
    var body: some View {
        NavigationView {
            ZStack{
                MapWaypointViewController(viewModel: viewModel)
                HStack {
                    Spacer()
                    Button(action: {
                        viewModel.removeRoute()
                    }) {
                        Image(systemName: "trash.fill")
                            .foregroundColor(.red)
                            .padding(10)
                    }
                    .background(Color.white)
                    .clipShape(Circle())
                    .padding(16)
                    .padding(.bottom, 26)
                    .padding(.trailing, 16)
                }
            }.onChange(of: countrySettings.selectedCountry) { selectedCountry in
                print("MapWayPointView Selected Country in MapSinglePointView changed to: \(selectedCountry)")
                viewModel.updateMap(selectedCountry: selectedCountry)
                mapUpdateToken = UUID()
            }
        }.environmentObject(countrySettings)
    }
}
