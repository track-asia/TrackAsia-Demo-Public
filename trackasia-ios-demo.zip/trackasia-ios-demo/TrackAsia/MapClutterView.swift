//
//  MenuPointView.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 13/12/2023.
//
import SwiftUI
import Mapbox
//import MapboxAnnotationCluster
struct MapClutterView: View {
    @EnvironmentObject private var countrySettings: CountrySettings
    @ObservedObject private var viewModel: MapClusterViewModel = MapClusterViewModel()

    
    var body: some View {
        NavigationView {
            ZStack{
                MapClusterController(viewModel: viewModel)
            }.onChange(of: countrySettings.selectedCountry) { selectedCountry in
//                print("MapClutterView Selected Country in MapSinglePointView changed to: \(selectedCountry)")
//                viewModel.updateMap(selectedCountry: selectedCountry)
            }
        }.environmentObject(countrySettings)
    }
}

