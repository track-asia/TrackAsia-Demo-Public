//
//  DataResponse.swift
//  TrackAsiaDemo
//
//  Created by SangNguyen on 19/12/2023.
//

import Foundation

enum NetworkError: Error {
    case invalidData
    case requestFailed
}
